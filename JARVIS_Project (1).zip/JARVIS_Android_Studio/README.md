# JARVIS Android starter (v0.1.0)

This is an Android Studio project scaffold that wraps the existing JARVIS interface in a native Android shell.

## Included
- Existing JARVIS HTML interface bundled locally in the APK.
- Native Android speech-input screen via `RecognizerIntent` (requires microphone permission and a compatible Android speech service).
- Native Android text-to-speech for spoken JARVIS replies.
- Android `ACTION_SET_ALARM` intent with the parsed hour/minute prefilled in the user's Clock app. The user reviews and saves the alarm.
- No `INTERNET` permission, analytics SDK, advertising SDK, remote JavaScript, or external web assets declared by this project.

## Important privacy/feature limits
- The app itself has no internet permission. The separate Android speech-recognition service may have its own network behaviour; this project cannot guarantee that voice transcription is offline.
- No local LLM is bundled. Unrecognised commands fall back to the existing prototype response.
- Alarm setting opens the system Clock UI; it does not silently schedule alarms.
- No wake-word listening in the background, SMS/OTP reading, automatic calling, camera capture, or routine learning is implemented.
- The native JavaScript bridge is intended for this bundled local page only. Do not load remote pages into this WebView.

## Build the APK
1. Install Android Studio on a computer and install Android SDK Platform 35 plus a compatible JDK (JDK 17 is the safe choice for this Gradle/Android Gradle Plugin combination).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (typically `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer the APK to your Motorola, install it, and grant microphone permission when prompted.

## Suggested test sequence
1. Launch JARVIS and type `daily briefing`.
2. Tap voice input, grant microphone access, and say `privacy status`.
3. Type `set an alarm for 7:30 AM`, confirm the dialog, and verify Clock opens with the requested time.
4. Disable internet on the phone and retest voice input. If the system speech service fails offline, that confirms the current speech provider is not offline-capable on this device; it does not mean the JARVIS interface needs internet.

## Next stage
To guarantee offline speech recognition, integrate a bundled offline model such as a suitable Vosk model, after verifying the model's language coverage, size, licensing, and performance on the target device. A local LLM would be a separate later component.
