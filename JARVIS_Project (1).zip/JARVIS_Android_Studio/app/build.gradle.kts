plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tahir.jarvis"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tahir.jarvis"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    buildFeatures { buildConfig = true }
}

kotlin { jvmToolchain(17) }
