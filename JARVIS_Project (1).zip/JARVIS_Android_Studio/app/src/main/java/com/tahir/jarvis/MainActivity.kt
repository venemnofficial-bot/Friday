package com.tahir.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var pendingVoiceRequest = false

    companion object {
        private const val VOICE_REQUEST = 701
        private const val MIC_PERMISSION_REQUEST = 702
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "JarvisAndroid")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/jarvis_prototype.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun startVoice() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    pendingVoiceRequest = true
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(Manifest.permission.RECORD_AUDIO),
                        MIC_PERMISSION_REQUEST
                    )
                    return@runOnUiThread
                }
                launchVoiceInput()
            }
        }

        @JavascriptInterface
        fun stopVoice() {
            // RecognizerIntent is a system activity; it is stopped by the user cancelling that screen.
            runOnUiThread { evaluateJs("window.jarvisNativeVoiceStopped && window.jarvisNativeVoiceStopped()") }
        }

        @JavascriptInterface
        fun setAlarm(hour: Int, minute: Int, label: String) {
            runOnUiThread {
                if (hour !in 0..23 || minute !in 0..59) {
                    Toast.makeText(this@MainActivity, "Invalid alarm time", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val intent = Intent(AlarmClockIntent.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClockIntent.EXTRA_HOUR, hour)
                    putExtra(AlarmClockIntent.EXTRA_MINUTES, minute)
                    putExtra(AlarmClockIntent.EXTRA_MESSAGE, label.take(80))
                    putExtra(AlarmClockIntent.EXTRA_SKIP_UI, false)
                }
                try {
                    startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(this@MainActivity, "No compatible Clock app found. Please set the alarm manually.", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun speak(text: String) {
            val safeText = text.take(1200)
            runOnUiThread {
                tts?.speak(safeText, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
            }
        }
    }

    private fun launchVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            startActivityForResult(intent, VOICE_REQUEST)
        } catch (_: ActivityNotFoundException) {
            evaluateJs("window.jarvisNativeVoiceError && window.jarvisNativeVoiceError('No Android speech recognition service is installed.')")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIC_PERMISSION_REQUEST) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted && pendingVoiceRequest) launchVoiceInput()
            else evaluateJs("window.jarvisNativeVoiceError && window.jarvisNativeVoiceError('Microphone permission was denied.')")
            pendingVoiceRequest = false
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQUEST) {
            if (resultCode == RESULT_OK) {
                val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    val escaped = org.json.JSONObject.quote(spoken)
                    evaluateJs("window.jarvisNativeVoiceResult && window.jarvisNativeVoiceResult($escaped)")
                } else {
                    evaluateJs("window.jarvisNativeVoiceError && window.jarvisNativeVoiceError('No speech was recognised. Please try again.')")
                }
            } else {
                evaluateJs("window.jarvisNativeVoiceError && window.jarvisNativeVoiceError('Voice input was cancelled.')")
            }
        }
    }

    private fun evaluateJs(script: String) {
        if (::webView.isInitialized) webView.post { webView.evaluateJavascript(script, null) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }

    // Standard Android AlarmClock intent constants, declared here to avoid API-level surprises.
    private object AlarmClockIntent {
        const val ACTION_SET_ALARM = "android.intent.action.SET_ALARM"
        const val EXTRA_HOUR = "android.intent.extra.alarm.HOUR"
        const val EXTRA_MINUTES = "android.intent.extra.alarm.MINUTES"
        const val EXTRA_MESSAGE = "android.intent.extra.alarm.MESSAGE"
        const val EXTRA_SKIP_UI = "android.intent.extra.alarm.SKIP_UI"
    }
}
